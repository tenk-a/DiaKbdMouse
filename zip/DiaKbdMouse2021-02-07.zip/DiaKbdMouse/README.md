# DiaKbdMouse

Windows機にて、 Appsキー同時押しで、カーソルでマウス操作したり、古のダイヤモンドカーソル(SDEX等)移動したりするためのソフト。

DiaKbdMouse.htm を参照のこと
